# Comments on 22/10/22

* Excellent description and narrative of the attack: it's clear what happened and how. 
* Very good description of the vulnerability although a CVE would have been good (or an explanation that no CVE is available). 
* Very good usage of STRIDE, although the spoofing is perhaps more an element of the vulnerability (i.e., what made the attack possible) rather than the attack. 
* Excellent selection and usage of references. 
