Feedback on 03/10/2022

* In general, the attack is described quite well, and most points are clear. However, a bit more depth on the actual attack would be: what happened? what was exploited? 
* Very good to mention who identified the attack group (Microsoft)
* Very good to use references, but they should ideally be cited in the description itself, e.g., what is the link to the statement from Microsoft identifying Nobelium? 
* STRIDE: good understand of the model, however, you don't have to identify each part of STRIDE in the attack, but rather to focuse on the main points. 
