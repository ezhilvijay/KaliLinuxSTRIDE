# Feedback on 22/10/22

* Excellent attack description and narrative, with an excellent level of detail. 
* Excellent description of the vulnerability
* Excellent understanding and application of the STRIDE model. 
* Excellent mention of other attacks using the same vulnerabilies! 
* Excellent usage of references. 

